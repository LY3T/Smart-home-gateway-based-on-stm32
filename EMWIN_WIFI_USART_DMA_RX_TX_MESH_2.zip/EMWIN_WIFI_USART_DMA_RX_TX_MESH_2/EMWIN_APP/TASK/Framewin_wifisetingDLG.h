#ifndef _Window_bgDLG_H
#define _Window_bgDLG_H
#include "sys.h"
#include "WM.h"
//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其它任何用途
//ALIENTEK STM32F103战舰开发板
//STemWin BUTTON使用
//正点原子@ALIENTEK
//技术论坛:www.openedv.com
//创建日期:2015/4/10
//版本：V1.0
//版权所有，盗版必究。
//Copyright(C) 广州市星翼电子科技有限公司 2014-2024
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 	
	


extern WM_HMEM Framewin_wifiseting;

extern char ssid_buff[20],pwd_buff[20];
extern char at_jap[40];
extern char flag_at_jap_ok;


WM_HWIN CreateFramewin_wifiseting(void);

#endif
