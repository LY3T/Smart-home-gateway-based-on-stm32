#ifndef __DMA_H
#define	__DMA_H	   
#include "sys.h"

void DMA1_USART3_init(void);
void DMA1_USART2_init(void);
#endif




